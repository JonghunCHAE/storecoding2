package org.zerock.board.repository.search;

import org.zerock.board.entity.Board;

public interface SearchBoardRepository {

    Board search1();
}
